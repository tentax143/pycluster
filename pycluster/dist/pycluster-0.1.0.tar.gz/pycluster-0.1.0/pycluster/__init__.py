"""
PyCluster - A Windows-based Python clustering package with dashboard support

This package provides a simple interface for creating distributed computing clusters
using Dask as the underlying framework. It supports head node/worker architecture
similar to Ray but with better Windows compatibility.
"""

__version__ = "0.1.0"
__author__ = "PyCluster Development Team"

from .cluster import ClusterManager
from .node import HeadNode, WorkerNode
from .dashboard import DashboardManager
from .windows_utils import WindowsClusterManager
from .network_utils import NetworkDiscovery

__all__ = [
    "ClusterManager", 
    "HeadNode", 
    "WorkerNode", 
    "DashboardManager",
    "WindowsClusterManager",
    "NetworkDiscovery"
]

